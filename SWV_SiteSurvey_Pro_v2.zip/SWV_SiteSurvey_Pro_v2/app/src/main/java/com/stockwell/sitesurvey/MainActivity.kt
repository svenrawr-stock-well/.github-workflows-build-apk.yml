package com.stockwell.sitesurvey

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.google.android.gms.location.LocationServices
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") { HomeScreen(nav) }
                    composable("settings") { SettingsScreen(nav) }
                    composable("form") { SurveyFormScreen(nav) }
                    composable("photos") { PhotoCaptureScreen(nav) }
                    composable("annotate") { PhotoAnnotateScreen(nav) }
                    composable("sketch") { SketchScreen(nav) }
                    composable("export") { ExportScreen(nav) }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(nav: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("SWV Site Survey Pro") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { nav.navigate("settings") }, modifier = Modifier.fillMaxWidth()) { Text("Settings (branding & company info)") }
            Button(onClick = { nav.navigate("form") }, modifier = Modifier.fillMaxWidth()) { Text("New/Update site survey") }
            Button(onClick = { nav.navigate("photos") }, modifier = Modifier.fillMaxWidth()) { Text("Add photos") }
            Button(onClick = { nav.navigate("annotate") }, modifier = Modifier.fillMaxWidth()) { Text("Annotate a photo") }
            Button(onClick = { nav.navigate("sketch") }, modifier = Modifier.fillMaxWidth()) { Text("Sketch with stylus") }
            Button(onClick = { nav.navigate("export") }, modifier = Modifier.fillMaxWidth()) { Text("Export & Share") }
        }
    }
}

/* ---------- Settings ---------- */
data class Settings(
    val companyName: String = "Stock-Well Vending",
    val phone: String = "",
    val email: String = "",
    val website: String = "",
    val address: String = "",
    val logoPath: String = "" // filesDir/logo.png
)

fun readSettings(ctx: Context): Settings {
    val f = File(ctx.filesDir, "settings.json")
    if (!f.exists()) return Settings()
    return try {
        val t = f.readText()
        Settings(
            companyName = Regex("\"companyName\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: "Stock-Well Vending",
            phone       = Regex("\"phone\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: "",
            email       = Regex("\"email\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: "",
            website     = Regex("\"website\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: "",
            address     = Regex("\"address\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: "",
            logoPath    = Regex("\"logoPath\":\\s*\"(.*?)\"").find(t)?.groupValues?.get(1) ?: ""
        )
    } catch (_: Throwable) { Settings() }
}

fun writeSettings(ctx: Context, s: Settings) {
    val f = File(ctx.filesDir, "settings.json")
    f.writeText(
        """
        {
          "companyName": "${s.companyName.replace("\"","'")}",
          "phone": "${s.phone.replace("\"","'")}",
          "email": "${s.email.replace("\"","'")}",
          "website": "${s.website.replace("\"","'")}",
          "address": "${s.address.replace("\"","'")}",
          "logoPath": "${s.logoPath.replace("\"","'")}"
        }
        """.trimIndent()
    )
}

@Composable
fun SettingsScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var settings by remember { mutableStateOf(readSettings(ctx)) }
    val pickLogo = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val dest = File(ctx.filesDir, "logo.png")
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                dest.outputStream().use { outs -> ins.copyTo(outs) }
            }
            settings = settings.copy(logoPath = dest.absolutePath)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { OutlinedTextField(settings.companyName, { settings = settings.copy(companyName = it) }, label = { Text("Company name") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(settings.phone, { settings = settings.copy(phone = it) }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(settings.email, { settings = settings.copy(email = it) }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(settings.website, { settings = settings.copy(website = it) }, label = { Text("Website") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(settings.address, { settings = settings.copy(address = it) }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { pickLogo.launch(ActivityResultContracts.PickVisualMedia.ImageOnly) }) { Text("Pick logo image") }
                    if (settings.logoPath.isNotEmpty()) Text("Logo selected")
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { writeSettings(ctx, settings) }) { Text("Save") }
                    Button(onClick = { nav.popBackStack() }) { Text("Back") }
                }
            }
        }
    }
}

/* ---------- Survey form (same as previous version with extra fields) ---------- */
data class SurveyForm(
    val siteName: String = "",
    val address: String = "",
    val contactName: String = "",
    val contactPhone: String = "",
    val contactEmail: String = "",
    val shiftsPerDay: Int = 1,
    val shiftHours: String = "",
    val daysPerWeek: Int = 5,
    val employeeCount: Int = 75,
    val headcountByShift: String = "",
    val hasExistingVending: String = "unknown",
    val powerOutletsCount: Int = 0,
    val distToNearestOutletFt: Int = 0,
    val spaceWidthIn: Int = 0,
    val spaceDepthIn: Int = 0,
    val spaceHeightIn: Int = 0,
    val clearanceNotes: String = "",
    val accessType: String = "front_door",
    val loadingNotes: String = "",
    val securityRestrictions: String = "",
    val parkingNotes: String = "",
    val breakroomsCount: Int = 1,
    val breakroomNotes: String = "",
    val wifiAvailable: Boolean = false,
    val cellSignalNotes: String = "",
    val spaceNotes: String = "",
    val createdAt: String = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
)

@Composable
fun SurveyFormScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var form by remember { mutableStateOf(loadLatestForm(ctx) ?: SurveyForm()) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Site survey") }) },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { saveForm(ctx, form) }) { Text("Save draft") }
                Button(onClick = { nav.popBackStack() }) { Text("Back") }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { OutlinedTextField(form.siteName, { form = form.copy(siteName = it) }, label = { Text("Site name") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.address, { form = form.copy(address = it) }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.contactName, { form = form.copy(contactName = it) }, label = { Text("Contact name") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.contactPhone, { form = form.copy(contactPhone = it) }, label = { Text("Contact phone") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.contactEmail, { form = form.copy(contactEmail = it) }, label = { Text("Contact email") }, modifier = Modifier.fillMaxWidth()) }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumberField("Shifts/day", form.shiftsPerDay) { form = form.copy(shiftsPerDay = it) }
                    OutlinedTextField(form.shiftHours, { form = form.copy(shiftHours = it) }, label = { Text("Shift hours") }, modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumberField("Days/week", form.daysPerWeek) { form = form.copy(daysPerWeek = it) }
                    NumberField("Employees", form.employeeCount) { form = form.copy(employeeCount = it) }
                }
            }
            item { OutlinedTextField(form.headcountByShift, { form = form.copy(headcountByShift = it) }, label = { Text("Headcount by shift") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Text("Existing vending?")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("yes","no","unknown").forEach { opt ->
                        FilterChip(selected = form.hasExistingVending == opt, onClick = { form = form.copy(hasExistingVending = opt) }, label = { Text(opt) })
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumberField("Outlets", form.powerOutletsCount) { form = form.copy(powerOutletsCount = it) }
                    NumberField("Dist to outlet (ft)", form.distToNearestOutletFt) { form = form.copy(distToNearestOutletFt = it) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumberField("Width (in)", form.spaceWidthIn) { form = form.copy(spaceWidthIn = it) }
                    NumberField("Depth (in)", form.spaceDepthIn) { form = form.copy(spaceDepthIn = it) }
                    NumberField("Height (in)", form.spaceHeightIn) { form = form.copy(spaceHeightIn = it) }
                }
            }
            item { OutlinedTextField(form.clearanceNotes, { form = form.copy(clearanceNotes = it) }, label = { Text("Clearance / obstructions") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Text("Access")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("front_door","dock","both").forEach { opt ->
                        FilterChip(selected = form.accessType == opt, onClick = { form = form.copy(accessType = opt) }, label = { Text(opt) })
                    }
                }
            }
            item { OutlinedTextField(form.loadingNotes, { form = form.copy(loadingNotes = it) }, label = { Text("Loading / elevators / ramps") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.securityRestrictions, { form = form.copy(securityRestrictions = it) }, label = { Text("Security restrictions") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.parkingNotes, { form = form.copy(parkingNotes = it) }, label = { Text("Parking / loading zones") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = form.wifiAvailable, onClick = { form = form.copy(wifiAvailable = !form.wifiAvailable) }, label = { Text(if (form.wifiAvailable) "Wi-Fi available" else "Wi-Fi not available") })
                    OutlinedTextField(form.cellSignalNotes, { form = form.copy(cellSignalNotes = it) }, label = { Text("Cell signal notes") }, modifier = Modifier.weight(1f))
                }
            }
            item { OutlinedTextField(form.breakroomNotes, { form = form.copy(breakroomNotes = it) }, label = { Text("Breakroom notes") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(form.spaceNotes, { form = form.copy(spaceNotes = it) }, label = { Text("Other notes") }, modifier = Modifier.fillMaxWidth(), minLines = 3) }
        }
    }
}

@Composable
fun NumberField(label: String, value: Int, onChange: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { s -> s.toIntOrNull()?.let(onChange) },
        label = { Text(label) },
        modifier = Modifier.width(140.dp)
    )
}

fun saveForm(ctx: Context, form: SurveyForm) {
    val dir = File(ctx.filesDir, "surveys"); dir.mkdirs()
    val ts = System.currentTimeMillis()
    File(dir, "survey_${ts}.json").writeText(
        """
        {
          "siteName": "${form.siteName.replace("\"","'")}",
          "address": "${form.address.replace("\"","'")}",
          "contactName": "${form.contactName.replace("\"","'")}",
          "contactPhone": "${form.contactPhone.replace("\"","'")}",
          "contactEmail": "${form.contactEmail.replace("\"","'")}",
          "shiftsPerDay": ${form.shiftsPerDay},
          "shiftHours": "${form.shiftHours.replace("\"","'")}",
          "daysPerWeek": ${form.daysPerWeek},
          "employeeCount": ${form.employeeCount},
          "headcountByShift": "${form.headcountByShift.replace("\"","'")}",
          "hasExistingVending": "${form.hasExistingVending}",
          "powerOutletsCount": ${form.powerOutletsCount},
          "distToNearestOutletFt": ${form.distToNearestOutletFt},
          "spaceWidthIn": ${form.spaceWidthIn},
          "spaceDepthIn": ${form.spaceDepthIn},
          "spaceHeightIn": ${form.spaceHeightIn},
          "clearanceNotes": "${form.clearanceNotes.replace("\"","'")}",
          "accessType": "${form.accessType}",
          "loadingNotes": "${form.loadingNotes.replace("\"","'")}",
          "securityRestrictions": "${form.securityRestrictions.replace("\"","'")}",
          "parkingNotes": "${form.parkingNotes.replace("\"","'")}",
          "breakroomsCount": ${form.breakroomsCount},
          "breakroomNotes": "${form.breakroomNotes.replace("\"","'")}",
          "wifiAvailable": ${form.wifiAvailable},
          "cellSignalNotes": "${form.cellSignalNotes.replace("\"","'")}",
          "spaceNotes": "${form.spaceNotes.replace("\"","'")}",
          "createdAt": "${form.createdAt}"
        }
        """.trimIndent()
    )
}

fun loadLatestForm(ctx: Context): SurveyForm? {
    val dir = File(ctx.filesDir, "surveys")
    val f = dir.listFiles()?.filter { it.extension == "json" }?.maxByOrNull { it.lastModified() } ?: return null
    return try { SurveyForm(siteName = Regex("\"siteName\":\\s*\"(.*?)\"").find(f.readText())?.groupValues?.get(1) ?: "") } catch (_: Throwable) { null }
}

/* ---------- Photos with timestamp/location ---------- */
data class CapturedPhoto(val uri: Uri, val timestamp: String, val locationText: String?)

@Composable
fun PhotoCaptureScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var last by remember { mutableStateOf<CapturedPhoto?>(null) }

    val requestCamera = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    val requestLocation = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    val takePicture = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success -> }

    fun newImageUri(): Uri {
        val name = "SW_${System.currentTimeMillis()}.jpg"
        val resolver = ctx.contentResolver
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SWSiteSurvey")
        }
        return resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Add photos") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { requestCamera.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
                Button(onClick = { requestLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Text("Allow location") }
            }
            Button(onClick = {
                val uri = newImageUri()
                takePicture.launch(uri)
                // For simplicity, we only stamp timestamp; location requires fused provider setup
                last = CapturedPhoto(uri, LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME), null)
            }) { Text("Capture photo") }

            last?.let { cp ->
                AsyncImage(model = cp.uri, contentDescription = "latest photo", modifier = Modifier.fillMaxWidth().height(320.dp).border(1.dp, Color.Gray))
                Text("Captured: ${cp.timestamp}")
            }

            Button(onClick = { nav.navigate("annotate") }) { Text("Annotate a photo") }
            Button(onClick = { nav.popBackStack() }) { Text("Back") }
        }
    }
}

/* ---------- Photo Annotation ---------- */
data class StrokePath(val points: MutableList<Offset> = mutableListOf(), val width: Float = 6f)

@Composable
fun PhotoAnnotateScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var targetUri by remember { mutableStateOf<Uri?>(null) }
    val strokes = remember { mutableStateListOf<StrokePath>() }
    var current by remember { mutableStateOf<StrokePath?>(null) }

    val pickPhoto = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) targetUri = uri }

    Scaffold(topBar = { TopAppBar(title = { Text("Annotate photo") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { pickPhoto.launch(ActivityResultContracts.PickVisualMedia.ImageOnly) }) { Text("Pick photo") }
                Button(onClick = { strokes.clear() }) { Text("Clear") }
                Button(onClick = { targetUri?.let { saveAnnotated(ctx, it, strokes) } }) { Text("Save annotated") }
            }

            Box(Modifier.fillMaxWidth().height(420.dp).background(Color(0xFF101010)).border(1.dp, Color.Gray)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o -> current = StrokePath(mutableListOf(o), 6f) },
                        onDragEnd = { current?.let { strokes.add(it) }; current = null },
                        onDrag = { change, _ ->
                            val w = if (change.type == PointerType.Stylus) 8f else 6f
                            val pos = change.position
                            if (current == null) current = StrokePath(mutableListOf(pos), w)
                            current?.points?.add(pos)
                        }
                    )
                }
            ) {
                targetUri?.let { AsyncImage(model = it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
                Canvas(modifier = Modifier.fillMaxSize()) {
                    fun drawStroke(sp: StrokePath) {
                        val path = Path()
                        sp.points.firstOrNull()?.let { start ->
                            path.moveTo(start.x, start.y)
                            for (p in sp.points.drop(1)) path.lineTo(p.x, p.y)
                            drawPath(path, color = Color.Yellow, style = Stroke(width = sp.width))
                        }
                    }
                    strokes.forEach { drawStroke(it) }
                    current?.let { drawStroke(it) }
                }
            }

            Button(onClick = { nav.popBackStack() }) { Text("Back") }
        }
    }
}

fun saveAnnotated(ctx: Context, baseUri: Uri, strokes: List<StrokePath>) {
    val src = ctx.contentResolver.openInputStream(baseUri) ?: return
    val bmp = BitmapFactory.decodeStream(src); src.close()
    val canvas = android.graphics.Canvas(bmp.copy(android.graphics.Bitmap.Config.ARGB_8888, true))
    val paint = android.graphics.Paint().apply {
        style = android.graphics.Paint.Style.STROKE
        color = android.graphics.Color.YELLOW
        strokeWidth = 8f
        isAntiAlias = true
        strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    strokes.forEach { sp ->
        paint.strokeWidth = sp.width
        var last: Offset? = null
        sp.points.forEach { p ->
            last?.let { l -> canvas.drawLine(l.x, l.y, p.x, p.y, paint) }
            last = p
        }
    }

    val name = "Annotated_${System.currentTimeMillis()}.jpg"
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SWSiteSurvey")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { out ->
        (canvas.bitmap).compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)
    }
}

/* ---------- Sketch ---------- */
@Composable
fun SketchScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val strokes = remember { mutableStateListOf<StrokePath>() }
    var current by remember { mutableStateOf<StrokePath?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Sketch pad") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.fillMaxWidth().height(360.dp).background(Color(0xFF101010)).border(1.dp, Color.Gray)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o -> current = StrokePath(mutableListOf(o), 6f) },
                        onDragEnd = { current?.let { strokes.add(it) }; current = null },
                        onDrag = { change, _ ->
                            val w = if (change.type == PointerType.Stylus) 8f else 6f
                            val pos = change.position
                            if (current == null) current = StrokePath(mutableListOf(pos), w)
                            current?.points?.add(pos)
                        }
                    )
                }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    fun drawStroke(sp: StrokePath) {
                        val path = Path()
                        sp.points.firstOrNull()?.let { start ->
                            path.moveTo(start.x, start.y)
                            for (p in sp.points.drop(1)) path.lineTo(p.x, p.y)
                            drawPath(path, color = Color.White, style = Stroke(width = sp.width))
                        }
                    }
                    strokes.forEach { drawStroke(it) }
                    current?.let { drawStroke(it) }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { strokes.clear() }) { Text("Clear") }
                Button(onClick = { saveSketch(ctx, strokes) }) { Text("Save sketch") }
                Button(onClick = { nav.popBackStack() }) { Text("Back") }
            }
        }
    }
}

fun saveSketch(ctx: Context, strokes: List<StrokePath>) {
    val w = 1600; val h = 900
    val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    canvas.drawColor(android.graphics.Color.parseColor("#101010"))
    val paint = android.graphics.Paint().apply {
        style = android.graphics.Paint.Style.STROKE
        color = android.graphics.Color.WHITE
        strokeWidth = 6f
        isAntiAlias = true
        strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    strokes.forEach { sp ->
        paint.strokeWidth = sp.width
        var last: Offset? = null
        sp.points.forEach { p ->
            last?.let { l -> canvas.drawLine(l.x, l.y, p.x, p.y, paint) }
            last = p
        }
    }

    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "Sketch_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SWSiteSurvey")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { out ->
        bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
    }
}

/* ---------- Export & Share ---------- */
@Composable
fun ExportScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("Export & Share") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("1) Generate branded PDF report\n2) Share a ZIP backup of forms+meta", fontWeight = FontWeight.SemiBold)
            Button(onClick = {
                status = try { exportPdf(ctx); "PDF saved to Documents/SWSiteSurvey" } catch (t: Throwable) { "Error: ${t.message}" }
            }) { Text("Export PDF") }
            Button(onClick = {
                status = try { shareBackupZip(ctx); "Opened share sheet for backup.zip" } catch (t: Throwable) { "Error: ${t.message}" }
            }) { Text("Share backup ZIP") }
            if (status.isNotEmpty()) Text(status)
            Button(onClick = { nav.popBackStack() }) { Text("Back") }
        }
    }
}

fun exportPdf(ctx: Context) {
    val settings = readSettings(ctx)
    val pdf = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(1240, 1754, 1).create()
    val p1 = pdf.startPage(pageInfo); val c = p1.canvas

    val bg = android.graphics.Paint().apply { color = android.graphics.Color.parseColor("#1F1F1F") }
    val head = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 46f; isFakeBoldText = true }
    val label = android.graphics.Paint().apply { color = android.graphics.Color.LTGRAY; textSize = 28f }
    val text = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 32f }
    val accent = android.graphics.Paint().apply { color = android.graphics.Color.parseColor("#FF6A00") }

    c.drawRect(0f, 0f, pageInfo.pageWidth.toFloat(), pageInfo.pageHeight.toFloat(), bg)
    c.drawRect(0f, 0f, pageInfo.pageWidth.toFloat(), 140f, accent)

    // logo
    settings.logoPath.takeIf { it.isNotEmpty() }?.let { path ->
        try {
            val bmp = BitmapFactory.decodeFile(path)
            val scaled = android.graphics.Bitmap.createScaledBitmap(bmp, 120, 120, true)
            c.drawBitmap(scaled, 40f, 10f, null)
        } catch (_: Throwable) {}
    }
    c.drawText(settings.companyName.ifEmpty { "Stock-Well Vending" }, 180f, 80f, head)
    val compInfo = listOf(settings.phone, settings.email, settings.website, settings.address).filter { it.isNotBlank() }.joinToString("  |  ")
    c.drawText(compInfo, 180f, 120f, text)

    // Latest form
    val dir = File(ctx.filesDir, "surveys")
    val latest = dir.listFiles()?.filter { it.extension == "json" }?.maxByOrNull { it.lastModified() }
    val form = latest?.readText() ?: "{}"

    var y = 200f
    fun row(l: String, v: String) { c.drawText(l, 40f, y, label); c.drawText(v, 320f, y, text); y += 44f }
    fun find(k: String) = Regex("\"$k\":\\s*\"(.*?)\"").find(form)?.groupValues?.get(1) ?: ""

    row("Site:", find("siteName"))
    row("Address:", find("address"))
    row("Contact:", find("contactName"))
    row("Phone:", find("contactPhone"))
    row("Email:", find("contactEmail"))
    row("Shifts/day:", Regex("\"shiftsPerDay\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "")
    row("Shift hours:", find("shiftHours"))
    row("Days/week:", Regex("\"daysPerWeek\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "")
    row("Employees:", Regex("\"employeeCount\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "")
    row("Headcount by shift:", find("headcountByShift"))
    row("Existing vending:", find("hasExistingVending"))
    row("Outlets:", Regex("\"powerOutletsCount\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "")
    row("Distance to outlet (ft):", Regex("\"distToNearestOutletFt\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "")
    row("Space WxDxH (in):",
        (Regex("\"spaceWidthIn\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "") + " x " +
        (Regex("\"spaceDepthIn\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: "") + " x " +
        (Regex("\"spaceHeightIn\":\\s*(\\d+)").find(form)?.groupValues?.get(1) ?: ""))
    row("Clearance:", find("clearanceNotes"))
    row("Access:", find("accessType"))
    row("Loading:", find("loadingNotes"))
    row("Security:", find("securityRestrictions"))
    row("Parking:", find("parkingNotes"))
    row("Wi-Fi:", Regex("\"wifiAvailable\":\\s*(true|false)").find(form)?.groupValues?.get(1) ?: "")
    row("Cell signal:", find("cellSignalNotes"))
    row("Breakroom:", find("breakroomNotes"))
    row("Other notes:", find("spaceNotes"))

    pdf.finishPage(p1)

    // Page 2: photo grid
    val p2 = pdf.startPage(pageInfo); val c2 = p2.canvas
    c2.drawRect(0f, 0f, pageInfo.pageWidth.toFloat(), pageInfo.pageHeight.toFloat(), bg)
    c2.drawRect(0f, 0f, pageInfo.pageWidth.toFloat(), 140f, accent)
    c2.drawText("Photos & Sketches", 40f, 90f, head)

    val resolver = ctx.contentResolver
    val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
    val uriExt = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val cursor = resolver.query(uriExt, proj, MediaStore.Images.Media.RELATIVE_PATH + " like ?", arrayOf("%SWSiteSurvey%"), MediaStore.Images.Media.DATE_ADDED + " DESC")
    var col = 0; var rowi = 0; var count = 0
    cursor?.use {
        val idIdx = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameIdx = it.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
        while (it.moveToNext() && count < 6) {
            val id = it.getLong(idIdx)
            val name = it.getString(nameIdx) ?: ""
            val uri = Uri.withAppendedPath(uriExt, id.toString())
            resolver.openInputStream(uri)?.use { ins ->
                val bmp = BitmapFactory.decodeStream(ins)
                val thumb = android.graphics.Bitmap.createScaledBitmap(bmp, 360, 240, true)
                val x = 40f + col * 400f
                val yy = 180f + rowi * 260f
                c2.drawBitmap(thumb, x, yy, null)
                c2.drawText(name.take(26), x, yy + 260f - 10f, label)
                col += 1; if (col >= 3) { col = 0; rowi += 1 }
                count += 1
            }
        }
    }
    pdf.finishPage(p2)

    val name = "SW_SiteSurvey_${System.currentTimeMillis()}.pdf"
    val values = ContentValues().apply {
        put(MediaStore.Files.FileColumns.DISPLAY_NAME, name)
        put(MediaStore.Files.FileColumns.MIME_TYPE, "application/pdf")
        put(MediaStore.Files.FileColumns.RELATIVE_PATH, "Documents/SWSiteSurvey")
    }
    val outUri = ctx.contentResolver.insert(MediaStore.Files.getContentUri("external"), values) ?: return
    ctx.contentResolver.openOutputStream(outUri)?.use { out -> pdf.writeTo(out) }
    pdf.close()
}

fun shareBackupZip(ctx: Context) {
    val cache = File(ctx.cacheDir, "share"); cache.mkdirs()
    val zipFile = File(cache, "swv_backup.zip")
    java.util.zip.ZipOutputStream(zipFile.outputStream()).use { zos ->
        fun addDir(dir: File, rootName: String) {
            if (!dir.exists()) return
            dir.walkTopDown().filter { it.isFile }.forEach { file ->
                val entryName = "$rootName/" + file.relativeTo(dir).path.replace("\\", "/")
                zos.putNextEntry(java.util.zip.ZipEntry(entryName))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        addDir(File(ctx.filesDir, "surveys"), "surveys")
        addDir(File(ctx.filesDir, "photo_meta"), "photo_meta")
        // include settings + logo
        File(ctx.filesDir, "settings.json").takeIf { it.exists() }?.let {
            zos.putNextEntry(java.util.zip.ZipEntry("settings/settings.json")); it.inputStream().use { i -> i.copyTo(zos) }; zos.closeEntry()
        }
        File(ctx.filesDir, "logo.png").takeIf { it.exists() }?.let {
            zos.putNextEntry(java.util.zip.ZipEntry("settings/logo.png")); it.inputStream().use { i -> i.copyTo(zos) }; zos.closeEntry()
        }
    }
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", zipFile)
    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/zip"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(android.content.Intent.createChooser(send, "Share SWV backup"))
}
